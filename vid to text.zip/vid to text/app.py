#!/usr/bin/env python
# coding: utf-8

# In[ ]:

from os import getcwd
from flask import Flask, render_template, request, jsonify
import speech_recognition as sr
from pydub import AudioSegment
from pydub.utils import make_chunks
import os
from deep_translator import GoogleTranslator as Translator
from spellchecker import SpellChecker
from summa import summarizer
import  moviepy.editor as mp
from flask_cors import CORS
app = Flask(__name__)
CORS(app)
@app.route('/extract', methods=['GET', 'POST'])
def extract():
    file = request.files['file']
    cwd =getcwd()
    file = str(str(cwd) + '/'+str(file.filename))
    assert os.path.exists(file), "I did not find the file at, "+str(file)
    f = open(file,'r+') 
    f.close()
    path= os.path.splitext(str(file))[0]+'.wav'
    lang = request.args.get('lang')
    clip=mp.VideoFileClip(file)
    clip.audio.write_audiofile(path)
    
    r=sr.Recognizer()
    audio=sr.AudioFile(path)
    with audio as source:
      audio_file=r.record(source)
    if lang == 'arabic':
        try:
             t2=r.recognize_google(audio_file,language='ar-AR')
             res =t2
             return str(res)
        except sr.UnknownValueError as u:
             return str(u)
        except sr.RequestError as r:
            return str(r)


    elif lang =='english':
        try:
            t=r.recognize_google(audio_file,language='eng')
            res =t
            return str(res)
        except sr.UnknownValueError as u:
            return str(u)
        except sr.RequestError as r:
            return str(r)
    
@app.route('/summarize', methods=['GET', 'POST'])
def summarize():
    text=request.form['text']
    lang = request.args.get('lang')
    if lang =='arabic':
        summaized_text=summarizer.summarize(text, language ="arabic")
        sum_text="ملخص الفيديو : "+ summaized_text
        return sum_text
    elif lang =='english':
        summaized_text=summarizer.summarize(text, language ="english")
        sum_text="summarized text is: "+ summaized_text
        return sum_text
    

@app.route('/check', methods=['GET', 'POST'])
def check():
    word = request.form['text']
    lang = request.args.get('lang')
    if lang == 'arabic':
        corrector = SpellChecker(language='ar')
        correct_word = corrector.correction(word)
    else:        
        corrector = SpellChecker(language='en')
        correct_word = corrector.correction(word)
    return str(correct_word)
    

@app.route('/transelate', methods=['GET', 'POST'])   
def transelate():
    lang = request.args.get('lang')
    t = request.form['text']
    if lang == 'english':
        translator = Translator(source='auto', target='ar')
        result = translator.translate(t)
    else:
        translator = Translator(source='auto', target='en')
        result = translator.translate(t)
    return result

@app.route('/save', methods=['GET', 'POST'])   
def save():
    t = request.form['text']
    f2=open('videoText_AR.txt','a',encoding='utf-8')
    f2.writelines(t)
    f2.close()
    return 'تم'
if __name__ == '__main__':
    app.run(debug=True)

