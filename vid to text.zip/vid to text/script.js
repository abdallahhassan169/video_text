function convertVideo() {
    let videoFile = document.getElementById("video-file").files[0];

    let videoPlayer = document.createElement("video");
    videoPlayer.src = URL.createObjectURL(videoFile);

    let speechRecognizer = new webkitSpeechRecognition();
    speechRecognizer.continuous = true;
    speechRecognizer.interimResults = true;
    speechRecognizer.lang = "en-US";

    let textOutput = document.getElementById("text-output");
    textOutput.value = "";

    speechRecognizer.onresult = function(event) {
        let interimTranscript = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
            let transcript = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
                textOutput.value += transcript;
            } else {
                interimTranscript += transcript;
            }
        }
        if (interimTranscript !== "") {
            textOutput.value += interimTranscript;
        }
    };

    videoPlayer.onloadedmetadata = function() {
        speechRecognizer.start();
        videoPlayer.play();
    };
}
// Set default language to English
let currentLanguage = 'english';

// Listen for button clicks
document.getElementById('english-button').addEventListener('click', function() {
    // Set current language to English
    currentLanguage = 'english';
    // Update button styles
    document.getElementById('english-button').classList.add('active');
    document.getElementById('arabic-button').classList.remove('active');
    // Call function to update page content in English
    updatePageContent();
});

document.getElementById('arabic-button').addEventListener('click', function() {
    // Set current language to Arabic
    currentLanguage = 'arabic';
    // Update button styles
    document.getElementById('english-button').classList.remove('active');
    document.getElementById('arabic-button').classList.add('active');
    // Call function to update page content in Arabic
    updatePageContent();
});

function updatePageContent() {
    // Use currentLanguage variable to update page content based on language
    if (currentLanguage === 'english') {
        // Update page content to English
    } else if (currentLanguage === 'arabic') {
        // Update page content to Arabic
    }
}

<ul class="nav-links">
    <li><a href="#">Home</a></li>
    <li><a href="#">About</a></li>
    <li><a href="#">Contact</a></li>
    <li class="dropdown">
        <a href="#" class="dropbtn">Language</a>
        <div class="dropdown-content">
            <a href="#" class="lang-btn" data-lang="en">English</a>
            <a href="#" class="lang-btn" data-lang="ar">Arabic</a>
        </div>
    </li>
</ul>
</nav>
const form = document.querySelector('form');
const select = document.querySelector('select');

form.addEventListener('submit', (event) => {
event.preventDefault();
const selectedService = select.value;
console.log(`You selected ${selectedService}`);
// You can perform further actions with the selected service here
});
